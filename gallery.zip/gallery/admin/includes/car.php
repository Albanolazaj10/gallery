<?php 


class Car {


	 public function run() {

	 	echo "<h1>HELLO this is running</h1>";
	 }
}



?>