<?php



function classAutoLoader($class) {

   $class = strtolower($class);

   $the_path = INCLUDES_PATH."/{$class}.php";

   // Check to see whether the include declared the class
   if(is_file($the_path) && !class_exists($class)){
   	  include $the_path;
   }

}


spl_autoload_register('classAutoLoader');

function redirect($location) {
   header("Location: {$location}");
}

?>